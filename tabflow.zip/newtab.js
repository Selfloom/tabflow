// TabFlow — New Tab Page Controller
// Reads bookmarks, renders categories, search, dark mode, export, AI organize.

/* ================================================================
   State
   ================================================================ */
let allBookmarks = [];        // flat list of { id, title, url, parentId, dateAdded }
let categories = {};          // { categoryName: [bookmark, ...] }
let searchQuery = '';
let isDarkMode = null;        // null = follow system, true = dark, false = light

/* ================================================================
   DOM References
   ================================================================ */
const dom = {
  searchInput:       document.getElementById('searchInput'),
  searchClear:       document.getElementById('searchClear'),
  searchResults:     document.getElementById('searchResults'),
  searchResultsList: document.getElementById('searchResultsList'),
  categorySection:   document.getElementById('categorySection'),
  categoryGrid:      document.getElementById('categoryGrid'),
  categoryCount:     document.getElementById('categoryCount'),
  emptyState:        document.getElementById('emptyState'),
  statsBar:          document.getElementById('statsBar'),
  statsText:         document.getElementById('statsText'),
  suggestionsPanel:  document.getElementById('suggestionsPanel'),
  suggestionsList:   document.getElementById('suggestionsList'),
  aiOrganizeBtn:     document.getElementById('aiOrganizeBtn'),
  exportBtn:         document.getElementById('exportBtn'),
  darkModeToggle:    document.getElementById('darkModeToggle'),
  sunIcon:           document.getElementById('sunIcon'),
  moonIcon:          document.getElementById('moonIcon'),
  dismissSuggestions:document.getElementById('dismissSuggestions'),
  searchClearBtn:    document.getElementById('searchClear'),
};

/* ================================================================
   Initialization
   ================================================================ */
async function init() {
  await loadDarkModePreference();
  await loadBookmarks();
  bindEvents();
  render();
}

/**
 * Load dark mode preference from chrome.storage.local.
 */
async function loadDarkModePreference() {
  try {
    const data = await chrome.storage.local.get('tabflow_darkmode');
    if (data.tabflow_darkmode !== undefined) {
      isDarkMode = data.tabflow_darkmode;
      applyDarkMode();
    }
  } catch (err) {
    console.warn('TabFlow: could not load dark mode preference', err);
  }
}

/**
 * Apply dark mode class to body based on isDarkMode.
 */
function applyDarkMode() {
  document.body.classList.remove('dark', 'light');
  if (isDarkMode === true) {
    document.body.classList.add('dark');
  } else if (isDarkMode === false) {
    document.body.classList.add('light');
  }
  // null = no class, follow system preference via CSS media query
  updateDarkModeIcon();
}

function updateDarkModeIcon() {
  const isDark = isDarkMode === true ||
    (isDarkMode === null && window.matchMedia('(prefers-color-scheme: dark)').matches);

  if (isDark) {
    dom.sunIcon.classList.add('hidden');
    dom.moonIcon.classList.remove('hidden');
  } else {
    dom.sunIcon.classList.remove('hidden');
    dom.moonIcon.classList.add('hidden');
  }
}

/* ================================================================
   Bookmark Loading
   ================================================================ */
async function loadBookmarks() {
  try {
    const tree = await chrome.bookmarks.getTree();
    allBookmarks = flattenTree(tree);
  } catch (err) {
    console.error('TabFlow: failed to load bookmarks', err);
    allBookmarks = [];
  }
}

/**
 * Flatten the bookmark tree into a list.
 * Skips the root nodes themselves, keeps folder names as metadata.
 */
function flattenTree(tree) {
  const result = [];

  function walk(nodes, parentFolder) {
    for (const node of nodes) {
      if (node.children) {
        // It's a folder — recurse with folder name
        walk(node.children, node.title);
      } else if (node.url) {
        // It's a bookmark
        result.push({
          id: node.id,
          title: node.title || 'Untitled',
          url: node.url,
          parentId: node.parentId,
          dateAdded: node.dateAdded,
          folder: parentFolder || null
        });
      }
    }
  }

  walk(tree, null);
  return result;
}

/* ================================================================
   Categorization
   ================================================================ */
function buildCategories() {
  const cats = {};

  for (const bm of allBookmarks) {
    // Use the bookmark's folder as its category
    // "Bookmarks bar" / "Other bookmarks" → Uncategorized
    let cat = bm.folder;
    if (!cat || cat === 'Bookmarks bar' || cat === 'Other bookmarks' || cat === 'Bookmarks') {
      cat = 'Uncategorized';
    }

    if (!cats[cat]) cats[cat] = [];
    cats[cat].push(bm);
  }

  return cats;
}

/* ================================================================
   Rendering
   ================================================================ */
function render() {
  categories = buildCategories();

  if (searchQuery.trim()) {
    renderSearchResults();
  } else {
    renderCategoryView();
  }

  updateStats();
}

function updateStats() {
  const total = allBookmarks.length;
  const catCount = Object.keys(categories).length;

  if (total === 0) {
    dom.statsText.textContent = 'No bookmarks found.';
  } else {
    dom.statsText.textContent = `${total} bookmark${total !== 1 ? 's' : ''} across ${catCount} categor${catCount !== 1 ? 'ies' : 'y'}`;
  }
}

function renderCategoryView() {
  dom.searchResults.classList.add('hidden');
  dom.categorySection.classList.remove('hidden');

  const catNames = Object.keys(categories).sort((a, b) => {
    // Uncategorized always last
    if (a === 'Uncategorized') return 1;
    if (b === 'Uncategorized') return -1;
    return categories[b].length - categories[a].length;
  });

  if (catNames.length === 0) {
    dom.emptyState.classList.remove('hidden');
    dom.categoryGrid.innerHTML = '';
    dom.categoryCount.textContent = '';
    return;
  }

  dom.emptyState.classList.add('hidden');
  dom.categoryCount.textContent = `${catNames.length} categor${catNames.length !== 1 ? 'ies' : 'y'}`;

  dom.categoryGrid.innerHTML = catNames.map(name => {
    const bookmarks = categories[name];

    return `
      <div class="category-card" data-category="${escapeHtml(name)}">
        <div class="card-header">
          <span class="card-title">${escapeHtml(name)}</span>
          <span class="card-badge">${bookmarks.length}</span>
        </div>
        <ul class="card-list">
          ${bookmarks.slice(0, 5).map(bm => `
            <li class="card-list-item" data-url="${escapeHtml(bm.url)}" title="${escapeHtml(bm.title)}">
              <img src="https://www.google.com/s2/favicons?domain=${encodeURIComponent(extractDomainSimple(bm.url))}&sz=32"
                   alt="" class="favicon"
                   loading="lazy"
                   onerror="this.style.display='none'">
              <span class="bm-title">${escapeHtml(bm.title)}</span>
            </li>
          `).join('')}
        </ul>
        ${bookmarks.length > 5 ? `
          <div class="card-more">
            <span class="card-more-link">+${bookmarks.length - 5} more</span>
          </div>
        ` : ''}
      </div>
    `;
  }).join('');

  // Attach click handlers to bookmark items
  dom.categoryGrid.querySelectorAll('.card-list-item').forEach(el => {
    el.addEventListener('click', (e) => {
      e.preventDefault();
      const url = el.dataset.url;
      if (url) window.location.href = url;
    });
  });
}

function renderSearchResults() {
  dom.categorySection.classList.add('hidden');
  dom.searchResults.classList.remove('hidden');
  dom.emptyState.classList.add('hidden');

  const q = searchQuery.toLowerCase().trim();
  const results = allBookmarks.filter(bm => {
    return bm.title.toLowerCase().includes(q) ||
           bm.url.toLowerCase().includes(q) ||
           (bm.folder && bm.folder.toLowerCase().includes(q));
  });

  if (results.length === 0) {
    dom.searchResultsList.innerHTML = `
      <div class="empty-state">
        <p>No bookmarks matching "${escapeHtml(q)}"</p>
      </div>
    `;
    return;
  }

  dom.searchResultsList.innerHTML = results.slice(0, 100).map(bm => {
    const domain = extractDomainSimple(bm.url);
    return `
      <div class="bookmark-item" data-url="${escapeHtml(bm.url)}">
        <img src="https://www.google.com/s2/favicons?domain=${encodeURIComponent(domain)}&sz=32"
             alt="" class="favicon" loading="lazy"
             onerror="this.style.display='none'">
        <div class="bm-info">
          <div class="bm-title">${highlightMatch(bm.title, q)}</div>
          <div class="bm-url">${highlightMatch(domain, q)}</div>
        </div>
        ${bm.folder ? `<span class="bm-tag">${escapeHtml(bm.folder)}</span>` : ''}
      </div>
    `;
  }).join('');

  // Click handlers
  dom.searchResultsList.querySelectorAll('.bookmark-item').forEach(el => {
    el.addEventListener('click', () => {
      const url = el.dataset.url;
      if (url) window.location.href = url;
    });
  });
}

function highlightMatch(text, query) {
  if (!query) return escapeHtml(text);
  const escaped = escapeHtml(text);
  const qEscaped = escapeHtml(query);
  // Case-insensitive regex highlighting
  const regex = new RegExp(`(${qEscaped.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
  return escaped.replace(regex, '<mark>$1</mark>');
}

/* ================================================================
   AI Organize
   ================================================================ */
async function runAIOrganize() {
  dom.aiOrganizeBtn.disabled = true;
  dom.aiOrganizeBtn.innerHTML = '<span class="spinner"></span> Organizing...';

  try {
    const tags = await categorizeAll(allBookmarks);

    // Build suggestions grouped by category
    const byCategory = {};
    for (const [id, result] of Object.entries(tags)) {
      const cat = result.category;
      if (!byCategory[cat]) byCategory[cat] = [];
      const bm = allBookmarks.find(b => b.id === id);
      if (bm) {
        byCategory[cat].push({ ...bm, confidence: result.confidence });
      }
    }

    renderSuggestions(byCategory, tags);
    dom.aiOrganizeBtn.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16">
        <path d="M20 6L9 17l-5-5"/>
      </svg>
      Organized
    `;
    setTimeout(() => {
      dom.aiOrganizeBtn.innerHTML = `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16">
          <path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/>
        </svg>
        AI Organize
      `;
      dom.aiOrganizeBtn.disabled = false;
    }, 2000);
  } catch (err) {
    console.error('TabFlow: AI organize failed', err);
    dom.aiOrganizeBtn.innerHTML = 'AI Organize';
    dom.aiOrganizeBtn.disabled = false;
  }
}

function renderSuggestions(byCategory, allTags) {
  dom.suggestionsPanel.classList.remove('hidden');

  const catNames = Object.keys(byCategory).sort((a, b) => {
    if (a === 'Uncategorized') return 1;
    if (b === 'Uncategorized') return -1;
    return byCategory[b].length - byCategory[a].length;
  });

  dom.suggestionsList.innerHTML = catNames.map(cat => {
    const items = byCategory[cat];
    return `
      <div style="margin-bottom: 16px;">
        <div style="font-weight: 600; font-size: 0.9rem; margin-bottom: 6px; color: var(--text-primary);">
          ${escapeHtml(cat)} <span class="card-badge">${items.length}</span>
        </div>
        ${items.slice(0, 8).map(bm => `
          <div class="bookmark-item" data-url="${escapeHtml(bm.url)}">
            <img src="https://www.google.com/s2/favicons?domain=${encodeURIComponent(extractDomainSimple(bm.url))}&sz=32"
                 alt="" class="favicon" loading="lazy"
                 onerror="this.style.display='none'">
            <div class="bm-info">
              <div class="bm-title">${escapeHtml(bm.title)}</div>
              <div class="bm-url">${escapeHtml(extractDomainSimple(bm.url))}</div>
            </div>
            <span class="bm-tag" style="opacity:${bm.confidence === 'high' ? '1' : bm.confidence === 'medium' ? '0.7' : '0.5'}">
              ${bm.confidence}
            </span>
          </div>
        `).join('')}
        ${items.length > 8 ? `<div style="font-size: 0.8rem; color: var(--text-tertiary); padding: 4px 14px;">+${items.length - 8} more...</div>` : ''}
      </div>
    `;
  }).join('');

  // Click handlers for suggestion items
  dom.suggestionsList.querySelectorAll('.bookmark-item').forEach(el => {
    el.addEventListener('click', () => {
      const url = el.dataset.url;
      if (url) window.location.href = url;
    });
  });
}

/* ================================================================
   Export
   ================================================================ */
async function exportBookmarks() {
  try {
    const tree = await chrome.bookmarks.getTree();
    const json = JSON.stringify(tree, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = `tabflow-export-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  } catch (err) {
    console.error('TabFlow: export failed', err);
    alert('Export failed. See console for details.');
  }
}

/* ================================================================
   Dark Mode Toggle
   ================================================================ */
async function toggleDarkMode() {
  // Cycle: null (system) → true (dark) → false (light) → null
  if (isDarkMode === null) {
    isDarkMode = true;
  } else if (isDarkMode === true) {
    isDarkMode = false;
  } else {
    isDarkMode = null;
  }

  applyDarkMode();

  try {
    await chrome.storage.local.set({ tabflow_darkmode: isDarkMode });
  } catch (err) {
    console.warn('TabFlow: could not save dark mode preference', err);
  }
}

/* ================================================================
   Event Bindings
   ================================================================ */
function bindEvents() {
  // Search input
  dom.searchInput.addEventListener('input', debounce(() => {
    searchQuery = dom.searchInput.value;
    if (searchQuery.trim()) {
      dom.searchClearBtn.classList.remove('hidden');
    } else {
      dom.searchClearBtn.classList.add('hidden');
    }
    render();
  }, 150));

  // Clear search
  dom.searchClearBtn.addEventListener('click', () => {
    dom.searchInput.value = '';
    searchQuery = '';
    dom.searchClearBtn.classList.add('hidden');
    dom.searchInput.focus();
    render();
  });

  // Escape key to clear search
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && searchQuery) {
      dom.searchInput.value = '';
      searchQuery = '';
      dom.searchClearBtn.classList.add('hidden');
      render();
      dom.searchInput.blur();
    }
  });

  // AI Organize
  dom.aiOrganizeBtn.addEventListener('click', runAIOrganize);

  // Export
  dom.exportBtn.addEventListener('click', exportBookmarks);

  // Dark mode toggle
  dom.darkModeToggle.addEventListener('click', toggleDarkMode);

  // Dismiss suggestions
  dom.dismissSuggestions.addEventListener('click', () => {
    dom.suggestionsPanel.classList.add('hidden');
  });

  // Listen for system color scheme changes (when isDarkMode === null)
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
    if (isDarkMode === null) {
      updateDarkModeIcon();
    }
  });
}

/* ================================================================
   Utilities
   ================================================================ */
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function extractDomainSimple(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    const match = url.match(/^(?:https?:\/\/)?(?:www\.)?([^\/:]+)/i);
    return match ? match[1] : '';
  }
}

function debounce(fn, delay) {
  let timer;
  return function (...args) {
    clearTimeout(timer);
    timer = setTimeout(() => fn.apply(this, args), delay);
  };
}

/* ================================================================
   Boot
   ================================================================ */
document.addEventListener('DOMContentLoaded', init);
