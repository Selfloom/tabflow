// TabFlow Categorizer — keyword-based bookmark auto-tagger
// No AI API needed. Runs fully local.

const CATEGORY_RULES = [
  // Development
  {
    category: 'Development',
    domains: ['github.com', 'stackoverflow.com', 'npmjs.com', 'gitlab.com', 'bitbucket.org',
              'dev.to', 'code.visualstudio.com', 'docker.com', 'kubernetes.io'],
    keywords: ['github', 'stackoverflow', 'npm', 'git', 'docker', 'kubernetes', 'code', 'dev', 'programming']
  },
  // Media
  {
    category: 'Media',
    domains: ['youtube.com', 'vimeo.com', 'twitch.tv', 'netflix.com', 'hulu.com',
              'spotify.com', 'disneyplus.com', 'hbomax.com', 'dailymotion.com'],
    keywords: ['video', 'watch', 'stream', 'music', 'playlist', 'episode', 'movie']
  },
  // Social
  {
    category: 'Social',
    domains: ['reddit.com', 'twitter.com', 'x.com', 'news.ycombinator.com', 'facebook.com',
              'instagram.com', 'discord.com', 'slack.com', 'telegram.org', 'tiktok.com',
              'threads.net', 'bsky.app', 'mastodon.social'],
    keywords: ['social', 'community', 'chat', 'discussion', 'forum', 'post']
  },
  // Shopping
  {
    category: 'Shopping',
    domains: ['amazon.com', 'ebay.com', 'etsy.com', 'aliexpress.com', 'walmart.com',
              'target.com', 'bestbuy.com', 'shopify.com', 'newegg.com'],
    keywords: ['buy', 'shop', 'price', 'deal', 'discount', 'product', 'order', 'cart']
  },
  // Productivity
  {
    category: 'Productivity',
    domains: ['docs.google.com', 'notion.so', 'airtable.com', 'figma.com', 'trello.com',
              'asana.com', 'monday.com', 'clickup.com', 'linear.app', 'miro.com',
              'canva.com', 'todoist.com', 'evernote.com'],
    keywords: ['docs', 'document', 'sheet', 'slide', 'board', 'project', 'task', 'note', 'design']
  },
  // Reading
  {
    category: 'Reading',
    domains: ['medium.com', 'substack.com', 'blog', 'wikipedia.org', 'nytimes.com',
              'theguardian.com', 'wsj.com', 'bloomberg.com', 'techcrunch.com', 'theverge.com',
              'wired.com', 'arstechnica.com'],
    keywords: ['article', 'blog', 'read', 'news', 'story', 'post', 'essay', 'wiki']
  },
  // Research
  {
    category: 'Research',
    domains: ['arxiv.org', 'scholar.google.com', 'researchgate.net', 'sci-hub.se',
              'pubmed.ncbi.nlm.nih.gov', 'ieee.org', 'acm.org', 'springer.com',
              'nature.com', 'science.org'],
    keywords: ['paper', 'research', 'study', 'journal', 'doi', 'abstract', 'thesis', 'publication']
  },
  // Career
  {
    category: 'Career',
    domains: ['linkedin.com', 'indeed.com', 'glassdoor.com', 'monster.com',
              'ziprecruiter.com', 'levels.fyi', 'blindapp.com'],
    keywords: ['job', 'career', 'resume', 'interview', 'salary', 'hiring', 'recruiter']
  }
];

const TLD_CATEGORIES = {
  '.edu': 'Education',
  '.gov': 'Government',
  '.org': 'Organizations',
  '.mil': 'Military'
};

/**
 * Extract domain from a URL string.
 * @param {string} url
 * @returns {string} e.g. "github.com"
 */
function extractDomain(url) {
  try {
    const u = new URL(url);
    return u.hostname.replace(/^www\./, '').toLowerCase();
  } catch {
    // Try regex fallback for malformed URLs
    const match = url.match(/^(?:https?:\/\/)?(?:www\.)?([^\/:]+)/i);
    return match ? match[1].toLowerCase() : '';
  }
}

/**
 * Categorize a single bookmark by its URL and title.
 * @param {{ id: string, title: string, url: string }} bookmark
 * @returns {{ category: string, confidence: 'high'|'medium'|'low' }}
 */
function categorizeBookmark(bookmark) {
  const domain = extractDomain(bookmark.url || '');
  const title = (bookmark.title || '').toLowerCase();
  const combined = domain + ' ' + title;

  // Check domain matches first (highest confidence)
  for (const rule of CATEGORY_RULES) {
    for (const d of rule.domains) {
      if (domain.includes(d)) {
        return { category: rule.category, confidence: 'high' };
      }
    }
  }

  // Check keyword matches (medium confidence)
  for (const rule of CATEGORY_RULES) {
    for (const kw of rule.keywords) {
      if (combined.includes(kw)) {
        return { category: rule.category, confidence: 'medium' };
      }
    }
  }

  // TLD fallback (low confidence)
  for (const [tld, category] of Object.entries(TLD_CATEGORIES)) {
    if (domain.endsWith(tld)) {
      return { category, confidence: 'low' };
    }
  }

  return { category: 'Uncategorized', confidence: 'low' };
}

/**
 * Categorize all bookmarks in a flat list.
 * Store suggestions in chrome.storage.local.
 * @param {Array<{ id: string, title: string, url: string }>} bookmarks
 * @returns {Promise<Object>} Map of bookmark ID → { category, confidence }
 */
async function categorizeAll(bookmarks) {
  const results = {};

  for (const bm of bookmarks) {
    if (!bm.url) continue; // skip folders
    const result = categorizeBookmark(bm);
    results[bm.id] = result;
  }

  // Persist to chrome.storage.local
  await chrome.storage.local.set({ tabflow_tags: results });
  return results;
}

/**
 * Get previously stored tags from chrome.storage.local.
 * @returns {Promise<Object>}
 */
async function getStoredTags() {
  const data = await chrome.storage.local.get('tabflow_tags');
  return data.tabflow_tags || {};
}

/**
 * Get suggested category for a specific bookmark.
 * Returns stored tag if available, otherwise computes fresh.
 * @param {{ id: string, title: string, url: string }} bookmark
 * @returns {Promise<string>} category name
 */
async function getCategory(bookmark) {
  if (!bookmark.url) return 'Folder';

  const stored = await getStoredTags();
  if (stored[bookmark.id]) {
    return stored[bookmark.id].category;
  }

  const result = categorizeBookmark(bookmark);
  return result.category;
}
