# TabFlow — AI Bookmark Dashboard

Replace your new tab page with an AI-organized bookmark dashboard. Zero dependencies, fully local.

## What it does

- **Replaces your new tab page** with a clean, modern bookmark dashboard
- **Auto-categorizes bookmarks** by folder structure
- **Search** across all bookmarks by title or URL — instant, client-side
- **AI Organize** — one-click keyword-based categorization that suggests tags for every bookmark
- **Dark mode** — follows system preference, with manual toggle
- **Export** bookmarks as JSON — one click, downloads your full bookmark tree

## Installation

### Load as an unpacked extension

1. Open Chrome and go to `chrome://extensions/`
2. Turn on **Developer mode** (toggle in the top-right corner)
3. Click **Load unpacked**
4. Select the `workspace/tabflow/` folder (the one containing `manifest.json`)
5. Open a new tab — you should see TabFlow

### Verify it works

- Your existing Chrome bookmarks should appear as category cards
- Type in the search bar to filter
- Click any bookmark to open it
- Click **AI Organize** to see suggested categories
- Toggle the sun/moon icon to switch themes

## Files

| File | Purpose |
|------|---------|
| `manifest.json` | Chrome Manifest V3 config |
| `newtab.html` | New tab page HTML |
| `newtab.js` | Main controller: bookmark loading, rendering, search, export |
| `categorizer.js` | Keyword-based auto-tagger (8 categories + TLD fallback) |
| `style.css` | Full dark/light theme with CSS custom properties |
| `icons/icon.svg` | Vector icon (source) |
| `icons/icon128.png` | 128x128 PNG icon for Chrome |

## Tech

- **Zero dependencies** — vanilla HTML, CSS, JavaScript
- **No accounts, no servers** — everything stored in `chrome.storage.local`
- **Manifest V3** — current Chrome extension standard
- **`chrome.bookmarks` API** — reads your existing bookmarks
- **`chrome.storage.local`** — persists dark mode preference and AI tags

## Categorization logic

The AI Organize button uses a keyword-based categorizer (no external API):

| Category | Matches (domains/keywords) |
|----------|---------------------------|
| Development | github.com, stackoverflow.com, npm, git, docker... |
| Media | youtube.com, vimeo.com, netflix, video, stream... |
| Social | reddit.com, twitter.com, discord, forum... |
| Shopping | amazon.com, ebay.com, shop, price, deal... |
| Productivity | notion.so, figma.com, docs.google.com, project... |
| Reading | medium.com, substack.com, blog, article, news... |
| Research | arxiv.org, scholar.google.com, paper, journal... |
| Career | linkedin.com, indeed.com, job, resume... |

TLD fallback: `.edu` → Education, `.gov` → Government.
