# TabFlow Distribution Package

## Reddit Post Draft

**Subreddit:** r/chrome
**Title:** I got sick of Chrome's broken new tab page, so I built a free alternative that organizes your bookmarks

**Body:**

Chrome 148 forced the bookmarks bar onto the new tab page and it drove me insane. I had 400+ bookmarks spread across years of random saving — stuff I'd never find again.

So I built TabFlow: a free Chrome extension that replaces your new tab page with an AI-organized bookmark dashboard.

**What it does:**
- Replaces your new tab with a clean dashboard showing all your bookmarks organized by category
- "AI Organize" button auto-tags your bookmarks (Development, Media, Shopping, Research, etc.)
- Instant search across all bookmark titles and URLs
- Dark mode (because who uses light mode?)
- One-click JSON export (your data is yours, no accounts needed)
- Everything is stored locally on your machine — zero data sent anywhere

**Why I built it:**
I tried Raindrop.io but didn't want another account. OneTab kept losing my tabs (you know the stories). Bookmark OS felt like enterprise software for my personal links. I just wanted something that lives in my new tab and works.

**How to install (30 seconds):**
1. Download from GitHub: [link] or Chrome Web Store: [link pending review]
2. Go to `chrome://extensions/`, enable "Developer mode" (top right)
3. Click "Load unpacked" and select the `tabflow/` folder
4. Open a new tab — that's it

**What's next:**
It's free. I want to add cloud sync and smarter AI categorization as a Pro tier eventually, but the core organizer is free forever. If this saves one person from losing their research bookmarks like I did, it was worth it.

Would love feedback — what would make you switch from your current bookmark system?

---

## Chrome Web Store Listing Draft

**Name:** TabFlow - AI Bookmark Dashboard
**Short description:** Replace your new tab with an AI-organized bookmark dashboard. Search, categorize, and never lose a bookmark again.

**Detailed description:**

TabFlow replaces your Chrome new tab page with a clean, intelligent dashboard for all your bookmarks.

**Features:**
- AI-Powered Organization: Auto-categorize bookmarks into Development, Media, Shopping, Research, and more
- Instant Search: Find any bookmark by title or URL in milliseconds
- Clean New Tab: Replace Chrome's boring new tab with your organized bookmarks
- Dark Mode: Easy on the eyes, day and night
- JSON Export: Your data is yours — export all bookmarks with one click
- Local Storage: Everything stays on your machine. No accounts, no cloud, no tracking

**Perfect for:**
- Developers and researchers with hundreds of bookmarks
- Anyone who's ever said "I know I saved that link somewhere..."
- OneTab refugees tired of losing their tabs
- People who want a better new tab page

**Privacy:** TabFlow stores all data locally on your device. No data is ever sent to any server. No tracking, no analytics, no accounts required.

**Category:** Productivity
**Language:** English

---

## Screenshots Needed
- TabFlow new tab page in dark mode showing categories
- Search in action (typing a query, results appearing)
- AI Organize results panel
- Export dialog

---

## Chrome Web Store Assets Needed
- 128x128 icon (done: `icons/icon128.png`)
- 440x280 small tile image
- 920x680 large tile image  
- 1400x560 marquee image
- At least 1 screenshot (1280x800)
